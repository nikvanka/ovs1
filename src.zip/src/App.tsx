
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";

// Pages
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ElectionCreate from "./pages/admin/ElectionCreate";
import ElectionManage from "./pages/admin/ElectionManage";
import VoterDashboard from "./pages/voter/VoterDashboard";
import ElectionVote from "./pages/voter/ElectionVote";
import ResultsPage from "./pages/results/ResultsPage";
import NotFound from "./pages/NotFound";
import { Layout } from "./components/Layout";
import ProtectedRoute from "./components/auth/ProtectedRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<LandingPage />} />
              <Route path="login" element={<LoginPage />} />
              <Route path="register" element={<RegisterPage />} />
              
              {/* Admin Routes */}
              <Route path="admin" element={
                <ProtectedRoute requiredRole="ADMIN">
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              <Route path="admin/elections/create" element={
                <ProtectedRoute requiredRole="ADMIN">
                  <ElectionCreate />
                </ProtectedRoute>
              } />
              <Route path="admin/elections/:id" element={
                <ProtectedRoute requiredRole="ADMIN">
                  <ElectionManage />
                </ProtectedRoute>
              } />
              
              {/* Voter Routes */}
              <Route path="voter" element={
                <ProtectedRoute requiredRole="VOTER">
                  <VoterDashboard />
                </ProtectedRoute>
              } />
              <Route path="voter/elections/:id" element={
                <ProtectedRoute requiredRole="VOTER">
                  <ElectionVote />
                </ProtectedRoute>
              } />
              
              {/* Results Page - accessible by all authenticated users */}
              <Route path="results/:id" element={
                <ProtectedRoute>
                  <ResultsPage />
                </ProtectedRoute>
              } />
              
              {/* Catch all */}
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
