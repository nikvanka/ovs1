
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { toast } from '@/components/ui/use-toast';

// Define user roles
export type UserRole = 'ADMIN' | 'VOTER';

// Define user type
export interface User {
  id: string;
  username: string;
  email: string;
  role: UserRole;
  token: string;
}

// Define context type
interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
  isLoading: boolean;
  hasRole: (role: UserRole | UserRole[]) => boolean;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Mock API functions (to be replaced with real API calls)
const mockLogin = async (email: string, password: string): Promise<User> => {
  // In a real app, this would be an API call
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  if (email === 'admin@example.com' && password === 'admin123') {
    return {
      id: '1',
      username: 'Admin User',
      email: 'admin@example.com',
      role: 'ADMIN',
      token: 'mock-admin-token'
    };
  } else if (email === 'voter@example.com' && password === 'voter123') {
    return {
      id: '2',
      username: 'Voter User',
      email: 'voter@example.com',
      role: 'VOTER',
      token: 'mock-voter-token'
    };
  }
  
  throw new Error('Invalid credentials');
};

const mockRegister = async (username: string, email: string, password: string): Promise<User> => {
  // In a real app, this would be an API call
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  // Always register as a voter for now
  return {
    id: Math.random().toString(36).substr(2, 9),
    username,
    email,
    role: 'VOTER',
    token: 'mock-new-voter-token'
  };
};

// Auth provider component
export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('voteverse_user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
      } catch (error) {
        console.error('Failed to parse stored user data:', error);
        localStorage.removeItem('voteverse_user');
      }
    }
    setIsLoading(false);
  }, []);
  
  // Login function
  const login = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      const loggedInUser = await mockLogin(email, password);
      setUser(loggedInUser);
      localStorage.setItem('voteverse_user', JSON.stringify(loggedInUser));
      toast({
        title: 'Login successful',
        description: `Welcome back, ${loggedInUser.username}!`,
      });
    } catch (error) {
      let message = 'Failed to login';
      if (error instanceof Error) {
        message = error.message;
      }
      toast({
        title: 'Login failed',
        description: message,
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Register function
  const register = async (username: string, email: string, password: string) => {
    try {
      setIsLoading(true);
      const newUser = await mockRegister(username, email, password);
      setUser(newUser);
      localStorage.setItem('voteverse_user', JSON.stringify(newUser));
      toast({
        title: 'Registration successful',
        description: `Welcome, ${newUser.username}!`,
      });
    } catch (error) {
      let message = 'Failed to register';
      if (error instanceof Error) {
        message = error.message;
      }
      toast({
        title: 'Registration failed',
        description: message,
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };
  
  // Logout function
  const logout = () => {
    setUser(null);
    localStorage.removeItem('voteverse_user');
    toast({
      title: 'Logged out',
      description: 'You have been logged out successfully.',
    });
  };
  
  // Function to check if user has required role(s)
  const hasRole = (role: UserRole | UserRole[]): boolean => {
    if (!user) return false;
    
    if (Array.isArray(role)) {
      return role.includes(user.role);
    }
    
    return user.role === role;
  };
  
  const value = {
    user,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    isLoading,
    hasRole,
  };
  
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
