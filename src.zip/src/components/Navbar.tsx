
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Check, ChevronDown, LogOut, Menu, User, Vote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

const Navbar = () => {
  const { user, logout, isAuthenticated, hasRole } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };
  
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 flex">
          <Link to="/" className="flex items-center space-x-2">
            <Vote className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">Online Voting System</span>
          </Link>
        </div>
        
        {/* Desktop navigation */}
        <nav className="hidden md:flex flex-1 items-center space-x-4 lg:space-x-6">
          <Link to="/" className="text-sm font-medium hover:text-primary">
            Home
          </Link>
          {isAuthenticated ? (
            <>
              {hasRole('ADMIN') && (
                <Link to="/admin" className="text-sm font-medium hover:text-primary">
                  Admin Panel
                </Link>
              )}
              {hasRole('VOTER') && (
                <Link to="/voter" className="text-sm font-medium hover:text-primary">
                  My Elections
                </Link>
              )}
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium hover:text-primary">
                Login
              </Link>
              <Link to="/register" className="text-sm font-medium hover:text-primary">
                Register
              </Link>
            </>
          )}
        </nav>
        
        <div className="flex-1 flex items-center justify-end space-x-4">
          {isAuthenticated && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <User className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{user?.username}</p>
                    <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate(hasRole('ADMIN') ? '/admin' : '/voter')}>
                  <User className="mr-2 h-4 w-4" />
                  <span>Dashboard</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
          
          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={cn(
        "md:hidden",
        mobileMenuOpen ? "block" : "hidden"
      )}>
        <div className="space-y-1 px-4 pb-3 pt-2">
          <Link 
            to="/" 
            className="block py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
            onClick={() => setMobileMenuOpen(false)}
          >
            Home
          </Link>
          {isAuthenticated ? (
            <>
              {hasRole('ADMIN') && (
                <Link 
                  to="/admin" 
                  className="block py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Admin Panel
                </Link>
              )}
              {hasRole('VOTER') && (
                <Link 
                  to="/voter" 
                  className="block py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  My Elections
                </Link>
              )}
              <button 
                onClick={() => {
                  handleLogout();
                  setMobileMenuOpen(false);
                }} 
                className="block w-full text-left py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link 
                to="/login" 
                className="block py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
                onClick={() => setMobileMenuOpen(false)}
              >
                Login
              </Link>
              <Link 
                to="/register" 
                className="block py-2 px-3 text-base font-medium hover:bg-accent hover:text-accent-foreground rounded-md"
                onClick={() => setMobileMenuOpen(false)}
              >
                Register
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Navbar;
