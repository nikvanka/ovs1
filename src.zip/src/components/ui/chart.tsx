
import React from 'react';
import {
  Bar,
  Line,
  Pie,
  BarChart as RechartsBarChart,
  LineChart as RechartsLineChart,
  PieChart as RechartsPieChart,
  XAxis,
  YAxis,
  Tooltip as RechartsTooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
  Cell
} from 'recharts';

interface ChartProps {
  data: any;
  height?: number | string;
  className?: string;
}

export function BarChart({ data, height = '100%', className }: ChartProps) {
  return (
    <ResponsiveContainer width="100%" height={height} className={className}>
      <RechartsBarChart data={data.labels.map((label: string, i: number) => ({
        name: label,
        value: data.datasets[0].data[i]
      }))} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <RechartsTooltip />
        <Legend />
        <Bar 
          dataKey="value" 
          fill={data.datasets[0].backgroundColor[0] || "#8b5cf6"}
          name={data.datasets[0].label || "Value"}
        >
          {data.datasets[0].backgroundColor?.length > 1 && 
            data.labels.map((entry: any, index: number) => (
              <Cell key={`cell-${index}`} fill={data.datasets[0].backgroundColor[index % data.datasets[0].backgroundColor.length]} />
            ))
          }
        </Bar>
      </RechartsBarChart>
    </ResponsiveContainer>
  );
}

export function LineChart({ data, height = '100%', className }: ChartProps) {
  // Transform the data to Recharts expected format
  const transformedData = data.labels.map((label: string, i: number) => ({
    name: label,
    value: data.datasets[0].data[i]
  }));

  return (
    <ResponsiveContainer width="100%" height={height} className={className}>
      <RechartsLineChart 
        data={transformedData}
        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <RechartsTooltip />
        <Legend />
        <Line
          type="monotone"
          dataKey="value"
          stroke={data.datasets[0].borderColor || "#8b5cf6"}
          name={data.datasets[0].label || "Value"}
          activeDot={{ r: 8 }}
        />
      </RechartsLineChart>
    </ResponsiveContainer>
  );
}

export function PieChart({ data, height = '100%', className }: ChartProps) {
  // Transform the data to Recharts expected format
  const transformedData = data.labels.map((label: string, i: number) => ({
    name: label,
    value: data.datasets[0].data[i]
  }));

  return (
    <ResponsiveContainer width="100%" height={height} className={className}>
      <RechartsPieChart>
        <Pie
          data={transformedData}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={80}
          fill="#8b5cf6"
          dataKey="value"
          label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
        >
          {transformedData.map((entry: any, index: number) => (
            <Cell 
              key={`cell-${index}`} 
              fill={data.datasets[0].backgroundColor?.[index % (data.datasets[0].backgroundColor?.length || 1)] || "#8b5cf6"} 
            />
          ))}
        </Pie>
        <Legend />
        <RechartsTooltip />
      </RechartsPieChart>
    </ResponsiveContainer>
  );
}

interface BarListProps extends ChartProps {
  title?: string;
  value?: string;
}

export function BarList({ data, className }: BarListProps) {
  // This would be a simple horizontal bar list component, different from BarChart
  return (
    <div className={className}>
      {data.labels.map((label: string, i: number) => (
        <div key={i} className="flex items-center mb-2">
          <span className="w-1/3">{label}</span>
          <div className="w-2/3">
            <div className="relative pt-1">
              <div className="overflow-hidden h-2 text-xs flex rounded bg-muted">
                <div
                  style={{
                    width: `${(data.datasets[0].data[i] / Math.max(...data.datasets[0].data)) * 100}%`,
                    backgroundColor: data.datasets[0].backgroundColor?.[i % (data.datasets[0].backgroundColor?.length || 1)] || "#8b5cf6"
                  }}
                  className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center"
                ></div>
              </div>
              <div className="text-xs text-right mt-1">
                {data.datasets[0].data[i]}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
