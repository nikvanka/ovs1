
import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Calendar,
  ChevronDown,
  Download,
  Share2,
  Users,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/contexts/AuthContext';
import { BarChart, BarList, LineChart, PieChart } from '@/components/ui/chart';

// Mock election data
const getMockElection = (id: string) => ({
  id,
  title: 'Board Member Election',
  description: 'Vote for the new board members that will represent our community for the next term.',
  status: 'active',
  startDate: '2025-04-01T00:00:00Z',
  endDate: '2025-04-15T00:00:00Z',
  totalVoters: 450,
  votesCast: 300,
  candidates: [
    { id: 'c1', name: 'John Doe', votes: 126, percentage: 42 },
    { id: 'c2', name: 'Anna Kim', votes: 111, percentage: 37 },
    { id: 'c3', name: 'Mike Smith', votes: 63, percentage: 21 },
  ],
  votingHistory: [
    { date: '2025-04-01', votes: 50 },
    { date: '2025-04-02', votes: 32 },
    { date: '2025-04-03', votes: 47 },
    { date: '2025-04-04', votes: 38 },
    { date: '2025-04-05', votes: 25 },
    { date: '2025-04-06', votes: 18 },
    { date: '2025-04-07', votes: 42 },
    { date: '2025-04-08', votes: 48 },
  ],
});

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

const ResultsPage = () => {
  const { id } = useParams<{ id: string }>();
  const { hasRole } = useAuth();
  const [election, setElection] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Mock fetch election data
  useEffect(() => {
    setIsLoading(true);
    // Simulating API call
    setTimeout(() => {
      setElection(getMockElection(id || ''));
      setIsLoading(false);
    }, 800);
  }, [id]);
  
  if (isLoading) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-pulse space-y-4">
            <div className="h-6 w-48 bg-muted rounded"></div>
            <div className="h-32 w-96 bg-muted rounded"></div>
            <div className="h-6 w-32 bg-muted rounded"></div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!election) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Election not found</h2>
          <p className="text-muted-foreground">The election you are looking for does not exist or has been removed.</p>
          <Button asChild>
            <Link to={hasRole('ADMIN') ? '/admin' : '/voter'}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
      </div>
    );
  }
  
  // Prepare chart data
  const barChartData = {
    labels: election.candidates.map((c: any) => c.name),
    datasets: [
      {
        label: 'Votes',
        data: election.candidates.map((c: any) => c.votes),
        backgroundColor: ['#4f46e5', '#8b5cf6', '#a78bfa'],
      },
    ],
  };
  
  const pieChartData = {
    labels: election.candidates.map((c: any) => c.name),
    datasets: [
      {
        data: election.candidates.map((c: any) => c.votes),
        backgroundColor: ['#4f46e5', '#8b5cf6', '#a78bfa'],
      },
    ],
  };
  
  const lineChartData = {
    labels: election.votingHistory.map((h: any) => h.date.substring(5)),
    datasets: [
      {
        label: 'Daily Votes',
        data: election.votingHistory.map((h: any) => h.votes),
        borderColor: '#4f46e5',
        fill: false,
      },
    ],
  };
  
  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <div className="flex items-center mb-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link to={hasRole('ADMIN') ? '/admin' : '/voter'}>
                <ArrowLeft className="h-4 w-4" />
              </Link>
            </Button>
            <h1 className="text-2xl md:text-3xl font-bold">{election.title}</h1>
          </div>
          <p className="text-muted-foreground">{election.description}</p>
        </div>
        <div className="flex flex-wrap gap-2 mt-4 md:mt-0">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon">
                  <Share2 className="h-4 w-4" />
                  <span className="sr-only">Share</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Share results</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Export
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Export as PDF</DropdownMenuItem>
              <DropdownMenuItem>Export as CSV</DropdownMenuItem>
              <DropdownMenuItem>Export as Image</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-3 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Total Votes</p>
                <p className="text-2xl font-bold">{election.votesCast}</p>
              </div>
              <Users className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Participation Rate</p>
                <p className="text-2xl font-bold">{Math.round((election.votesCast / election.totalVoters) * 100)}%</p>
              </div>
              <div className="h-5 w-5 text-muted-foreground">%</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">End Date</p>
                <p className="text-2xl font-bold">{formatDate(election.endDate)}</p>
              </div>
              <Calendar className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="bar" className="mb-8">
        <TabsList>
          <TabsTrigger value="bar">Bar Chart</TabsTrigger>
          <TabsTrigger value="pie">Pie Chart</TabsTrigger>
          <TabsTrigger value="line">Voting Activity</TabsTrigger>
        </TabsList>
        <TabsContent value="bar" className="p-4 border rounded-md mt-2">
          <div className="h-80">
            <BarChart data={barChartData} />
          </div>
        </TabsContent>
        <TabsContent value="pie" className="p-4 border rounded-md mt-2">
          <div className="h-80">
            <PieChart data={pieChartData} />
          </div>
        </TabsContent>
        <TabsContent value="line" className="p-4 border rounded-md mt-2">
          <div className="h-80">
            <LineChart data={lineChartData} />
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Detailed Results</h2>
        <Card>
          <CardContent className="p-0">
            <div className="grid grid-cols-12 p-4 font-medium bg-muted/50">
              <div className="col-span-5 md:col-span-4">Candidate</div>
              <div className="col-span-3 md:col-span-4">Votes</div>
              <div className="col-span-4">Percentage</div>
            </div>
            <Separator />
            {election.candidates.map((candidate: any, index: number) => (
              <div key={candidate.id}>
                <div className="grid grid-cols-12 p-4 items-center">
                  <div className="col-span-5 md:col-span-4 font-medium">{candidate.name}</div>
                  <div className="col-span-3 md:col-span-4">{candidate.votes} votes</div>
                  <div className="col-span-4">
                    <div className="flex items-center gap-2">
                      <div className="w-full bg-muted rounded-full h-2.5">
                        <div 
                          className="bg-primary h-2.5 rounded-full" 
                          style={{ width: `${candidate.percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{candidate.percentage}%</span>
                    </div>
                  </div>
                </div>
                {index < election.candidates.length - 1 && <Separator />}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
      
      {hasRole('ADMIN') && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Voter Analytics (Admin Only)</h2>
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardContent className="p-6">
                <h3 className="font-medium mb-4">Voter Demographics</h3>
                <div className="h-64">
                  <PieChart 
                    data={{
                      labels: ['Age 18-24', 'Age 25-34', 'Age 35-44', 'Age 45-54', 'Age 55+'],
                      datasets: [{
                        data: [15, 25, 30, 20, 10],
                        backgroundColor: ['#4f46e5', '#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe'],
                      }]
                    }}
                  />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="font-medium mb-4">Voting Method</h3>
                <div className="h-64">
                  <PieChart 
                    data={{
                      labels: ['Mobile App', 'Website', 'Email Link'],
                      datasets: [{
                        data: [45, 40, 15],
                        backgroundColor: ['#4f46e5', '#8b5cf6', '#a78bfa'],
                      }]
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResultsPage;
