
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, 
  Clock, 
  FileText, 
  RefreshCw, 
  Search,
  Vote
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

// Mock data for elections
const mockElections = [
  {
    id: '1',
    title: 'Board Member Election',
    description: 'Vote for the new board members that will represent our community for the next term.',
    status: 'active',
    endDate: '2025-04-15T00:00:00Z',
    alreadyVoted: false,
  },
  {
    id: '4',
    title: 'Annual Policy Review',
    description: 'Review and approve updates to our community policies and guidelines.',
    status: 'active',
    endDate: '2025-04-20T00:00:00Z',
    alreadyVoted: true,
  },
  {
    id: '2',
    title: 'Budget Approval Vote',
    description: 'Approve the proposed budget for the upcoming fiscal year.',
    status: 'upcoming',
    endDate: '2025-05-07T00:00:00Z',
    alreadyVoted: false,
  },
  {
    id: '3',
    title: 'Committee Chair Selection',
    description: 'Select the chairs for all committees for the upcoming term.',
    status: 'completed',
    endDate: '2025-03-15T00:00:00Z',
    alreadyVoted: true,
  },
];

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

// Calculate days remaining
const getDaysRemaining = (dateString: string) => {
  const now = new Date();
  const endDate = new Date(dateString);
  const diffTime = endDate.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

const VoterDashboard = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Filter elections based on search query
  const filteredElections = mockElections.filter(election => 
    election.title.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Group elections by status
  const activeElections = filteredElections.filter(e => e.status === 'active');
  const upcomingElections = filteredElections.filter(e => e.status === 'upcoming');
  const completedElections = filteredElections.filter(e => e.status === 'completed');
  
  // Refresh elections (mock function)
  const refreshElections = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };
  
  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">My Elections</h1>
          <p className="text-muted-foreground">View and participate in available elections</p>
        </div>
        <div className="flex gap-2 items-center">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search elections..."
              className="pl-8 w-full md:w-[250px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" size="icon" onClick={refreshElections} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            <span className="sr-only">Refresh</span>
          </Button>
        </div>
      </div>
      
      {/* Active Elections */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <Vote className="mr-2 h-5 w-5 text-green-600" />
          Active Elections
        </h2>
        
        {activeElections.length === 0 ? (
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">No active elections available</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {activeElections.map(election => (
              <Card key={election.id} className="overflow-hidden">
                <div className={cn(
                  "h-2.5 w-full",
                  election.alreadyVoted ? "bg-blue-500" : "bg-green-500"
                )} />
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{election.title}</CardTitle>
                    <Badge variant="outline" className={election.alreadyVoted ? "bg-blue-100 text-blue-800" : "bg-green-100 text-green-800"}>
                      {election.alreadyVoted ? "Voted" : "Not Voted"}
                    </Badge>
                  </div>
                  <CardDescription>{election.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="mr-1 h-4 w-4" />
                      <span>Ends on {formatDate(election.endDate)}</span>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="mr-1 h-4 w-4" />
                      <span>{getDaysRemaining(election.endDate)} days remaining</span>
                    </div>
                    <Button 
                      className="w-full" 
                      variant={election.alreadyVoted ? "outline" : "default"}
                      asChild
                    >
                      <Link to={election.alreadyVoted ? `/results/${election.id}` : `/voter/elections/${election.id}`}>
                        {election.alreadyVoted ? "View Results" : "Vote Now"}
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {/* Upcoming Elections */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <Calendar className="mr-2 h-5 w-5 text-blue-600" />
          Upcoming Elections
        </h2>
        
        {upcomingElections.length === 0 ? (
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">No upcoming elections scheduled</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {upcomingElections.map(election => (
              <Card key={election.id}>
                <CardHeader>
                  <CardTitle>{election.title}</CardTitle>
                  <CardDescription>{election.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="mr-1 h-4 w-4" />
                      <span>Opening on {formatDate(election.endDate)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      
      {/* Past Elections */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center">
          <FileText className="mr-2 h-5 w-5 text-gray-600" />
          Past Elections
        </h2>
        
        {completedElections.length === 0 ? (
          <Card className="bg-muted/30">
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">No past elections available</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {completedElections.map(election => (
              <Card key={election.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle>{election.title}</CardTitle>
                    <Badge variant="outline" className="bg-gray-100 text-gray-800">
                      Completed
                    </Badge>
                  </div>
                  <CardDescription>{election.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Calendar className="mr-1 h-4 w-4" />
                      <span>Ended on {formatDate(election.endDate)}</span>
                    </div>
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={`/results/${election.id}`}>
                        View Results
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default VoterDashboard;
