
import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { AlertCircle, ArrowLeft, Calendar, CheckCircle, Clock, Info, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';

// Mock election data
const getMockElection = (id: string) => ({
  id,
  title: 'Board Member Election',
  description: 'Vote for the new board members that will represent our community for the next term.',
  instructions: 'Select one candidate from the list below. Your vote is confidential and secure.',
  status: 'active',
  startDate: '2025-04-01T00:00:00Z',
  endDate: '2025-04-15T00:00:00Z',
  candidates: [
    { id: 'c1', name: 'John Doe', bio: 'Current treasurer with 5 years of experience in financial management.' },
    { id: 'c2', name: 'Anna Kim', bio: 'Community organizer and former vice president of the neighborhood council.' },
    { id: 'c3', name: 'Mike Smith', bio: 'Small business owner with expertise in project management and budgeting.' },
  ],
});

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

const ElectionVote = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [election, setElection] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Mock fetch election data
  useEffect(() => {
    setIsLoading(true);
    // Simulating API call
    setTimeout(() => {
      setElection(getMockElection(id || ''));
      setIsLoading(false);
    }, 800);
  }, [id]);
  
  // Handle vote submission
  const handleSubmitVote = () => {
    if (!selectedCandidate) {
      toast({
        title: "No selection made",
        description: "Please select a candidate before submitting your vote.",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Mock API call to submit vote
    setTimeout(() => {
      toast({
        title: "Vote submitted successfully!",
        description: "Your vote has been recorded securely.",
        action: (
          <Button variant="outline" size="sm" onClick={() => navigate(`/results/${id}`)}>
            View Results
          </Button>
        ),
      });
      setIsSubmitting(false);
      
      // Redirect to results page after successful vote
      navigate(`/results/${id}`);
    }, 1500);
  };
  
  if (isLoading) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading election...</span>
        </div>
      </div>
    );
  }
  
  if (!election) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Election not found</h2>
          <p className="text-muted-foreground">The election you are looking for does not exist or has been removed.</p>
          <Button asChild>
            <Link to="/voter">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to My Elections
            </Link>
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="mb-8">
        <div className="flex items-center mb-2">
          <Button variant="ghost" size="sm" asChild className="mr-2">
            <Link to="/voter">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <h1 className="text-2xl md:text-3xl font-bold">{election.title}</h1>
        </div>
        <p className="text-muted-foreground">{election.description}</p>
      </div>
      
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Voting Instructions</AlertTitle>
            <AlertDescription>{election.instructions}</AlertDescription>
          </Alert>
          
          <Card>
            <CardHeader>
              <CardTitle>Choose Your Candidate</CardTitle>
              <CardDescription>Select one candidate from the options below</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup value={selectedCandidate || ''} onValueChange={setSelectedCandidate}>
                {election.candidates.map((candidate: any) => (
                  <div key={candidate.id} className="flex items-start space-x-2 mb-4">
                    <RadioGroupItem value={candidate.id} id={candidate.id} className="mt-1" />
                    <div className="grid gap-1.5">
                      <Label htmlFor={candidate.id} className="font-medium">
                        {candidate.name}
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        {candidate.bio}
                      </p>
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSubmitVote} disabled={!selectedCandidate || isSubmitting} className="w-full">
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting Vote...
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Submit Vote
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
          
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Important Notice</AlertTitle>
            <AlertDescription>
              Once your vote is submitted, it cannot be changed. Please review your selection carefully before submitting.
            </AlertDescription>
          </Alert>
        </div>
        
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Election Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-2">
                <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium">Voting Period</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(election.startDate)} - {formatDate(election.endDate)}
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-2">
                <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium">Time Remaining</p>
                  <p className="text-sm text-muted-foreground">
                    {Math.ceil((new Date(election.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Security Information</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Your vote is secured with end-to-end encryption. Your identity is kept confidential while ensuring the integrity of the election process.
              </p>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                <span>Tamper-proof ballots</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                <span>Encrypted communication</span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                <span>Vote verification</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ElectionVote;
