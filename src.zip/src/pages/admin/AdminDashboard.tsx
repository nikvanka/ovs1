
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  BarChart, 
  FileText, 
  Plus, 
  RefreshCw, 
  Search,
  Users,
  Vote
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';

// Mock data for elections
const mockElections = [
  {
    id: '1',
    title: 'Board Member Election',
    status: 'active',
    startDate: '2025-04-01T00:00:00Z',
    endDate: '2025-04-15T00:00:00Z',
    totalVoters: 450,
    votesCast: 300,
  },
  {
    id: '2',
    title: 'Budget Approval Vote',
    status: 'upcoming',
    startDate: '2025-05-01T00:00:00Z',
    endDate: '2025-05-07T00:00:00Z',
    totalVoters: 450,
    votesCast: 0,
  },
  {
    id: '3',
    title: 'Committee Chair Selection',
    status: 'completed',
    startDate: '2025-03-01T00:00:00Z',
    endDate: '2025-03-15T00:00:00Z',
    totalVoters: 450,
    votesCast: 384,
  },
  {
    id: '4',
    title: 'Annual Policy Review',
    status: 'active',
    startDate: '2025-04-05T00:00:00Z',
    endDate: '2025-04-20T00:00:00Z',
    totalVoters: 450,
    votesCast: 127,
  },
];

// Get status badge color
const getStatusColor = (status: string) => {
  switch (status) {
    case 'active':
      return 'bg-green-100 text-green-800';
    case 'upcoming':
      return 'bg-blue-100 text-blue-800';
    case 'completed':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

const AdminDashboard = () => {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Filter elections based on search query
  const filteredElections = mockElections.filter(election => 
    election.title.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Count elections by status
  const activeElections = mockElections.filter(e => e.status === 'active').length;
  const upcomingElections = mockElections.filter(e => e.status === 'upcoming').length;
  const completedElections = mockElections.filter(e => e.status === 'completed').length;
  
  // Refresh elections (mock function)
  const refreshElections = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };
  
  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage your elections and view analytics</p>
        </div>
        <Button asChild>
          <Link to="/admin/elections/create">
            <Plus className="mr-2 h-4 w-4" />
            Create Election
          </Link>
        </Button>
      </div>
      
      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-3 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Elections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{mockElections.length}</div>
              <Vote className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Voters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">450</div>
              <Users className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Overall Participation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">67%</div>
              <BarChart className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Election Status */}
      <div className="grid gap-4 md:grid-cols-3 mb-8">
        <Card className="bg-green-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Elections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeElections}</div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Elections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingElections}</div>
          </CardContent>
        </Card>
        <Card className="bg-gray-50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Completed Elections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedElections}</div>
          </CardContent>
        </Card>
      </div>
      
      {/* Elections List */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>All Elections</CardTitle>
          <CardDescription>Manage and monitor all your elections</CardDescription>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mt-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search elections..."
                className="pl-8 w-full sm:w-[300px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="sm" onClick={refreshElections} disabled={isLoading}>
              <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-1 md:grid-cols-12 p-4 font-medium bg-muted/50">
              <div className="md:col-span-4">Election</div>
              <div className="hidden md:block md:col-span-2">Status</div>
              <div className="hidden md:block md:col-span-2">Start Date</div>
              <div className="hidden md:block md:col-span-2">End Date</div>
              <div className="hidden md:block md:col-span-1">Votes</div>
              <div className="md:col-span-1"></div>
            </div>
            
            {filteredElections.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">
                No elections found
              </div>
            ) : (
              filteredElections.map(election => (
                <div key={election.id} className="grid grid-cols-1 md:grid-cols-12 p-4 border-t items-center">
                  <div className="md:col-span-4 mb-2 md:mb-0">
                    <div className="font-medium">{election.title}</div>
                    <div className="text-sm text-muted-foreground md:hidden">
                      Status: <span className={getStatusColor(election.status)}>{election.status}</span>
                    </div>
                  </div>
                  <div className="hidden md:block md:col-span-2">
                    <Badge className={getStatusColor(election.status)} variant="outline">
                      {election.status}
                    </Badge>
                  </div>
                  <div className="hidden md:block md:col-span-2 text-muted-foreground">
                    {formatDate(election.startDate)}
                  </div>
                  <div className="hidden md:block md:col-span-2 text-muted-foreground">
                    {formatDate(election.endDate)}
                  </div>
                  <div className="hidden md:block md:col-span-1">
                    {election.votesCast}/{election.totalVoters}
                  </div>
                  <div className="md:col-span-1 text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to={`/admin/elections/${election.id}`}>
                        <FileText className="h-4 w-4" />
                        <span className="sr-only">Manage</span>
                      </Link>
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminDashboard;
