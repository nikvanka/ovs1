
import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  ArrowLeft,
  Calendar,
  Edit2,
  FileBarChart2,
  Loader2,
  MoreHorizontal,
  Pause,
  Play,
  Trash2,
  User,
  UserPlus,
  Users
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/components/ui/use-toast';

// Mock election data
const getMockElection = (id: string) => ({
  id,
  title: 'Board Member Election',
  description: 'Vote for the new board members that will represent our community for the next term.',
  instructions: 'Select one candidate from the list below. Your vote is confidential and secure.',
  status: 'active',
  startDate: '2025-04-01T00:00:00Z',
  endDate: '2025-04-15T00:00:00Z',
  totalVoters: 450,
  votesCast: 300,
  candidates: [
    { id: 'c1', name: 'John Doe', bio: 'Current treasurer with 5 years of experience in financial management.', votes: 126 },
    { id: 'c2', name: 'Anna Kim', bio: 'Community organizer and former vice president of the neighborhood council.', votes: 111 },
    { id: 'c3', name: 'Mike Smith', bio: 'Small business owner with expertise in project management and budgeting.', votes: 63 },
  ],
  recentVoters: [
    { id: 'v1', name: 'Taylor Wilson', email: 'taylor@example.com', time: '2025-04-08T14:32:00Z' },
    { id: 'v2', name: 'Sandra Rodriguez', email: 'sandra@example.com', time: '2025-04-08T13:17:00Z' },
    { id: 'v3', name: 'Alex Johnson', email: 'alex@example.com', time: '2025-04-08T11:05:00Z' },
    { id: 'v4', name: 'Chris Martin', email: 'chris@example.com', time: '2025-04-08T10:43:00Z' },
    { id: 'v5', name: 'Diana Lee', email: 'diana@example.com', time: '2025-04-07T16:28:00Z' },
  ],
  votingHistory: [
    { date: '2025-04-01', votes: 50 },
    { date: '2025-04-02', votes: 32 },
    { date: '2025-04-03', votes: 47 },
    { date: '2025-04-04', votes: 38 },
    { date: '2025-04-05', votes: 25 },
    { date: '2025-04-06', votes: 18 },
    { date: '2025-04-07', votes: 42 },
    { date: '2025-04-08', votes: 48 },
  ],
});

// Format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};

// Format time
const formatTime = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
};

const ElectionManage = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [election, setElection] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newVoterEmail, setNewVoterEmail] = useState('');
  const [isAddingVoter, setIsAddingVoter] = useState(false);
  
  // Mock fetch election data
  useEffect(() => {
    setIsLoading(true);
    // Simulating API call
    setTimeout(() => {
      setElection(getMockElection(id || ''));
      setIsLoading(false);
    }, 800);
  }, [id]);
  
  // Pause/resume election
  const toggleElectionStatus = () => {
    setElection((prev: any) => ({
      ...prev,
      status: prev.status === 'active' ? 'paused' : 'active',
    }));
    
    toast({
      title: `Election ${election.status === 'active' ? 'paused' : 'resumed'}`,
      description: `"${election.title}" has been ${election.status === 'active' ? 'paused' : 'resumed'} successfully.`,
    });
  };
  
  // Delete election
  const handleDeleteElection = () => {
    navigate('/admin');
    
    toast({
      title: "Election deleted",
      description: `"${election.title}" has been deleted successfully.`,
    });
  };
  
  // Add voter
  const handleAddVoter = () => {
    if (!newVoterEmail) return;
    
    setIsAddingVoter(true);
    
    // Mock API call
    setTimeout(() => {
      setNewVoterEmail('');
      setIsAddingVoter(false);
      setIsDialogOpen(false);
      
      toast({
        title: "Voter added",
        description: `${newVoterEmail} has been added to the election.`,
      });
    }, 1000);
  };
  
  if (isLoading) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading election...</span>
        </div>
      </div>
    );
  }
  
  if (!election) {
    return (
      <div className="container py-12 px-4 md:px-6">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">Election not found</h2>
          <p className="text-muted-foreground">The election you are looking for does not exist or has been removed.</p>
          <Button asChild>
            <Link to="/admin">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Link>
          </Button>
        </div>
      </div>
    );
  }
  
  // Calculate participation rate
  const participationRate = Math.round((election.votesCast / election.totalVoters) * 100);
  
  return (
    <div className="container py-8 px-4 md:px-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <div className="flex items-center mb-2">
            <Button variant="ghost" size="sm" asChild className="mr-2">
              <Link to="/admin">
                <ArrowLeft className="h-4 w-4" />
              </Link>
            </Button>
            <h1 className="text-2xl md:text-3xl font-bold">{election.title}</h1>
            <Badge className="ml-2 bg-green-100 text-green-800" variant="outline">
              {election.status}
            </Badge>
          </div>
          <p className="text-muted-foreground">{election.description}</p>
        </div>
        <div className="flex gap-2 mt-4 md:mt-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <MoreHorizontal className="h-4 w-4" />
                <span className="ml-2">Actions</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => navigate(`/results/${id}`)}>
                <FileBarChart2 className="mr-2 h-4 w-4" />
                View Results
              </DropdownMenuItem>
              <DropdownMenuItem onClick={toggleElectionStatus}>
                {election.status === 'active' ? (
                  <>
                    <Pause className="mr-2 h-4 w-4" />
                    Pause Election
                  </>
                ) : (
                  <>
                    <Play className="mr-2 h-4 w-4" />
                    Resume Election
                  </>
                )}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`/admin/elections/edit/${id}`)}>
                <Edit2 className="mr-2 h-4 w-4" />
                Edit Election
              </DropdownMenuItem>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                    <Trash2 className="mr-2 h-4 w-4 text-destructive" />
                    <span className="text-destructive">Delete Election</span>
                  </DropdownMenuItem>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This action cannot be undone. This will permanently delete the election and all associated data.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteElection} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                      Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <div className="grid gap-6 md:grid-cols-3 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Participation</p>
                <p className="text-2xl font-bold">{participationRate}%</p>
                <p className="text-sm text-muted-foreground">{election.votesCast} / {election.totalVoters} voters</p>
              </div>
              <div className="h-16 w-16">
                <svg viewBox="0 0 100 100" className="h-full w-full">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#e2e8f0"
                    strokeWidth="10"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    fill="none"
                    stroke="#4f46e5"
                    strokeWidth="10"
                    strokeDasharray={`${participationRate * 2.51} ${251 - participationRate * 2.51}`}
                    strokeDashoffset="0"
                    transform="rotate(-90 50 50)"
                  />
                </svg>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Voting Period</p>
                <p className="text-xl font-medium">{formatDate(election.startDate)}</p>
                <p className="text-xl font-medium">{formatDate(election.endDate)}</p>
              </div>
              <Calendar className="h-10 w-10 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col justify-between h-full">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Quick Actions</p>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                <Button variant="outline" size="sm" asChild className="w-full">
                  <Link to={`/results/${id}`}>
                    <FileBarChart2 className="mr-2 h-4 w-4" />
                    Results
                  </Link>
                </Button>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Add Voter
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Voter</DialogTitle>
                      <DialogDescription>
                        Add a new voter to this election. They will receive an email invitation.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email Address
                        </label>
                        <Input
                          id="email"
                          placeholder="voter@example.com"
                          value={newVoterEmail}
                          onChange={(e) => setNewVoterEmail(e.target.value)}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddVoter} disabled={!newVoterEmail || isAddingVoter}>
                        {isAddingVoter ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Adding...
                          </>
                        ) : (
                          'Add Voter'
                        )}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="overview" className="mb-8">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="candidates">Candidates</TabsTrigger>
          <TabsTrigger value="voters">Voters</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Election Progress</CardTitle>
              <CardDescription>
                Current status and progress of the election
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm font-medium">Participation Rate</span>
                    <span className="text-sm font-medium">{participationRate}%</span>
                  </div>
                  <Progress value={participationRate} />
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Top Candidates</h3>
                    <div className="space-y-2">
                      {election.candidates
                        .sort((a: any, b: any) => b.votes - a.votes)
                        .slice(0, 3)
                        .map((candidate: any, index: number) => (
                          <div key={candidate.id} className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center mr-2">
                              <span className="text-xs">{index + 1}</span>
                            </div>
                            <div>
                              <p className="text-sm font-medium">{candidate.name}</p>
                              <p className="text-xs text-muted-foreground">{candidate.votes} votes</p>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium mb-2">Recent Activity</h3>
                    <div className="space-y-2">
                      {election.recentVoters.slice(0, 3).map((voter: any) => (
                        <div key={voter.id} className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center mr-2">
                            <User className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{voter.name}</p>
                            <p className="text-xs text-muted-foreground">
                              Voted at {formatTime(voter.time)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Election Settings</CardTitle>
              <CardDescription>
                Key settings and information for this election
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium">Status</p>
                  <p className="text-muted-foreground">{election.status}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Voting Method</p>
                  <p className="text-muted-foreground">Single Choice</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Created On</p>
                  <p className="text-muted-foreground">{formatDate('2025-03-25T00:00:00Z')}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium">Created By</p>
                  <p className="text-muted-foreground">Admin User</p>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <p className="text-sm font-medium mb-2">Voting Instructions</p>
                <p className="text-muted-foreground">{election.instructions}</p>
              </div>
            </CardContent>
          </Card>
          
          {election.status === 'active' && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Active Election</AlertTitle>
              <AlertDescription>
                This election is currently active. Voters can cast their votes until {formatDate(election.endDate)}.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>
        
        <TabsContent value="candidates">
          <Card>
            <CardHeader>
              <CardTitle>Candidate Management</CardTitle>
              <CardDescription>
                View and manage candidates for this election
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-12 p-4 font-medium bg-muted/50">
                  <div className="col-span-5">Candidate</div>
                  <div className="col-span-5">Bio</div>
                  <div className="col-span-2">Votes</div>
                </div>
                <Separator />
                {election.candidates.map((candidate: any, index: number) => (
                  <div key={candidate.id}>
                    <div className="grid grid-cols-12 p-4">
                      <div className="col-span-5">
                        <p className="font-medium">{candidate.name}</p>
                      </div>
                      <div className="col-span-5 text-muted-foreground text-sm">
                        {candidate.bio}
                      </div>
                      <div className="col-span-2">
                        {candidate.votes} ({Math.round((candidate.votes / election.votesCast) * 100)}%)
                      </div>
                    </div>
                    {index < election.candidates.length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="voters">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Voter Management</CardTitle>
                <CardDescription>
                  View and manage voters for this election
                </CardDescription>
              </div>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <UserPlus className="mr-2 h-4 w-4" />
                    Add Voter
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add Voter</DialogTitle>
                    <DialogDescription>
                      Add a new voter to this election. They will receive an email invitation.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium">
                        Email Address
                      </label>
                      <Input
                        id="email"
                        placeholder="voter@example.com"
                        value={newVoterEmail}
                        onChange={(e) => setNewVoterEmail(e.target.value)}
                      />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddVoter} disabled={!newVoterEmail || isAddingVoter}>
                      {isAddingVoter ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Adding...
                        </>
                      ) : (
                        'Add Voter'
                      )}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-12 p-4 font-medium bg-muted/50">
                  <div className="col-span-4">Name</div>
                  <div className="col-span-4">Email</div>
                  <div className="col-span-4">Voting Status</div>
                </div>
                <Separator />
                {election.recentVoters.map((voter: any, index: number) => (
                  <div key={voter.id}>
                    <div className="grid grid-cols-12 p-4">
                      <div className="col-span-4">
                        <p className="font-medium">{voter.name}</p>
                      </div>
                      <div className="col-span-4 text-muted-foreground">
                        {voter.email}
                      </div>
                      <div className="col-span-4">
                        <Badge className="bg-green-100 text-green-800" variant="outline">
                          Voted on {formatDate(voter.time)}
                        </Badge>
                      </div>
                    </div>
                    {index < election.recentVoters.length - 1 && <Separator />}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ElectionManage;
