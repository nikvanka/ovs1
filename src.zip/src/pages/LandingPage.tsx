
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle, Shield, Users, Vote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';

const LandingPage = () => {
  const { isAuthenticated, hasRole } = useAuth();
  
  const features = [
    {
      icon: <Shield className="h-10 w-10 text-primary" />,
      title: 'Secure Voting',
      description: 'End-to-end encrypted voting process ensures your vote remains confidential and tamper-proof.',
    },
    {
      icon: <Users className="h-10 w-10 text-primary" />,
      title: 'Easy Participation',
      description: 'Intuitive interface makes it easy for voters of all technical backgrounds to participate.',
    },
    {
      icon: <CheckCircle className="h-10 w-10 text-primary" />,
      title: 'Real-time Results',
      description: 'Monitor election progress with real-time analytics and result visualization.',
    },
  ];
  
  const testimonials = [
    {
      quote: "VoteVerse transformed how our organization runs elections. It's secure, easy to use, and has increased voter participation by 45%.",
      author: "Jane Smith",
      role: "Community Association President"
    },
    {
      quote: "The real-time results feature is a game-changer. Our members love being able to see the outcomes immediately after voting closes.",
      author: "Michael Johnson",
      role: "Student Union Director"
    },
    {
      quote: "Setting up complex elections used to take days. With VoteVerse, I can create a new election in minutes with all the security features we need.",
      author: "Amanda Rodriguez",
      role: "Election Administrator"
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 md:py-28 bg-gradient-to-b from-secondary/50 to-background">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="space-y-4 animate-fade-in">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tighter">
                Secure Online Voting <br />
                <span className="text-primary">Made Simple</span>
              </h1>
              <p className="text-muted-foreground md:text-xl max-w-[600px]">
                A modern, secure, and transparent voting platform for organizations of all sizes. Run elections with confidence and integrity.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                {isAuthenticated ? (
                  <Button asChild size="lg">
                    <Link to={hasRole('ADMIN') ? "/admin" : "/voter"}>
                      Go to Dashboard
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                ) : (
                  <>
                    <Button asChild size="lg">
                      <Link to="/register">
                        Get Started
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                    <Button asChild variant="outline" size="lg">
                      <Link to="/login">
                        Login
                      </Link>
                    </Button>
                  </>
                )}
              </div>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center">
                  <CheckCircle className="mr-1 h-4 w-4 text-primary" />
                  <span>Secure</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="mr-1 h-4 w-4 text-primary" />
                  <span>Transparent</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="mr-1 h-4 w-4 text-primary" />
                  <span>User-friendly</span>
                </div>
              </div>
            </div>
            <div className="lg:pl-10 animate-fade-in-delay-1">
              <div className="relative p-4 bg-white shadow-lg rounded-lg overflow-hidden border">
                <div className="p-6 space-y-6">
                  <div className="flex items-center justify-between border-b pb-4">
                    <div>
                      <h3 className="font-medium">Board Member Election</h3>
                      <p className="text-sm text-muted-foreground">Closes in 2 days</p>
                    </div>
                    <span className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">Active</span>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="bg-secondary/50 p-3 rounded-md flex items-center">
                      <div className="h-8 w-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-medium mr-3">JD</div>
                      <div>
                        <p className="font-medium">John Doe</p>
                        <p className="text-sm text-muted-foreground">42% (126 votes)</p>
                      </div>
                      <div className="ml-auto">
                        <div className="w-24 bg-blue-100 rounded-full h-2.5">
                          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '42%' }}></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-secondary/50 p-3 rounded-md flex items-center">
                      <div className="h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-medium mr-3">AK</div>
                      <div>
                        <p className="font-medium">Anna Kim</p>
                        <p className="text-sm text-muted-foreground">37% (111 votes)</p>
                      </div>
                      <div className="ml-auto">
                        <div className="w-24 bg-purple-100 rounded-full h-2.5">
                          <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '37%' }}></div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-secondary/50 p-3 rounded-md flex items-center">
                      <div className="h-8 w-8 bg-green-100 rounded-full flex items-center justify-center text-green-600 font-medium mr-3">MS</div>
                      <div>
                        <p className="font-medium">Mike Smith</p>
                        <p className="text-sm text-muted-foreground">21% (63 votes)</p>
                      </div>
                      <div className="ml-auto">
                        <div className="w-24 bg-green-100 rounded-full h-2.5">
                          <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '21%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">300 votes cast</span>
                      <Button size="sm" variant="outline">View Details</Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center space-y-4 mb-12 md:mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold">Why Choose VoteVerse?</h2>
            <p className="text-muted-foreground md:text-lg max-w-[800px] mx-auto">
              Built with advanced security and usability in mind, VoteVerse provides everything needed for a successful digital election.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className={`space-y-4 animate-fade-in-delay-${index + 1} p-6 border rounded-lg hover:shadow-md transition-shadow`}
              >
                <div>{feature.icon}</div>
                <h3 className="text-xl font-bold">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section className="py-16 md:py-24 bg-secondary/30">
        <div className="container px-4 md:px-6">
          <div className="text-center space-y-4 mb-12 md:mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold">How It Works</h2>
            <p className="text-muted-foreground md:text-lg max-w-[800px] mx-auto">
              VoteVerse simplifies the entire election process for both administrators and voters.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 animate-fade-in-delay-1">
            <div className="p-6 border bg-background rounded-lg text-center space-y-4">
              <div className="bg-primary/10 h-12 w-12 rounded-full flex items-center justify-center mx-auto">
                <span className="text-primary font-bold">1</span>
              </div>
              <h3 className="text-xl font-medium">Create Election</h3>
              <p className="text-muted-foreground">Admins set up elections with custom settings, add candidates, and define voting parameters.</p>
            </div>
            <div className="p-6 border bg-background rounded-lg text-center space-y-4">
              <div className="bg-primary/10 h-12 w-12 rounded-full flex items-center justify-center mx-auto">
                <span className="text-primary font-bold">2</span>
              </div>
              <h3 className="text-xl font-medium">Cast Votes</h3>
              <p className="text-muted-foreground">Voters log in securely, view available elections, and cast their vote with a simple interface.</p>
            </div>
            <div className="p-6 border bg-background rounded-lg text-center space-y-4">
              <div className="bg-primary/10 h-12 w-12 rounded-full flex items-center justify-center mx-auto">
                <span className="text-primary font-bold">3</span>
              </div>
              <h3 className="text-xl font-medium">View Results</h3>
              <p className="text-muted-foreground">Access real-time results with detailed analytics and visualization after voting is complete.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonials */}
      <section className="py-16 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="text-center space-y-4 mb-12 md:mb-16 animate-fade-in">
            <h2 className="text-3xl md:text-4xl font-bold">What Our Users Say</h2>
            <p className="text-muted-foreground md:text-lg max-w-[800px] mx-auto">
              Organizations of all sizes trust VoteVerse for their election needs.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className={`p-6 border rounded-lg animate-fade-in-delay-${index + 1}`}>
                <div className="text-4xl text-primary mb-4">"</div>
                <p className="text-muted-foreground mb-4">{testimonial.quote}</p>
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-16 md:py-24 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4 animate-fade-in">
              <h2 className="text-3xl font-bold">Ready to transform your election process?</h2>
              <p className="text-primary-foreground/80 md:text-lg">
                Join thousands of organizations using VoteVerse to run secure, transparent elections.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row justify-center md:justify-end gap-4 animate-fade-in-delay-1">
              {isAuthenticated ? (
                <Button asChild size="lg" variant="secondary">
                  <Link to={hasRole('ADMIN') ? "/admin" : "/voter"}>
                    Go to Dashboard
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              ) : (
                <>
                  <Button asChild size="lg" variant="secondary">
                    <Link to="/register">Get Started</Link>
                  </Button>
                  <Button asChild size="lg" variant="outline">
                    <Link to="/login">Sign In</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
